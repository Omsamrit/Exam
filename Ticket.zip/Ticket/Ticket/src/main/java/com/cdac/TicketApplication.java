package com.cdac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages= {"com.telcom.ticket.controller","com.telcom.ticket.service"})
@EntityScan(basePackages= {"com.telcom.ticket.model"})
@EnableJpaRepositories(basePackages= {"com.telcom.ticket.repository"})
public class TicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketApplication.class, args);
	}

}
