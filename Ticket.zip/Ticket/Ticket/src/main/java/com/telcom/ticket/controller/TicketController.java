package com.telcom.ticket.controller;

import com.telcom.ticket.model.Ticket;
import com.telcom.ticket.service.TicketService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {
    private final TicketService ticketService;

    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @PostMapping
    public ResponseEntity<Ticket> createTicket(@RequestBody Ticket ticket) {
        Ticket createdTicket = ticketService.createTicket(ticket);
        return new ResponseEntity<>(createdTicket, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Ticket> updateTicket(@PathVariable Long id, @RequestBody Ticket updatedDetails) {
        Ticket updatedTicket = ticketService.updateTicket(id, updatedDetails);
        return ResponseEntity.ok(updatedTicket);
    }

    @GetMapping("/open")
    public ResponseEntity<List<Ticket>> getAllOpenTickets() {
        List<Ticket> openTickets = ticketService.fetchAllOpenTickets();
        return ResponseEntity.ok(openTickets);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Ticket> getTicketById(@PathVariable Long id) {
        return ticketService.fetchTicketById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }
}
