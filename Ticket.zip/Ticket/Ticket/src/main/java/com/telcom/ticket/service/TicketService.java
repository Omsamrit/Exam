package com.telcom.ticket.service;

import com.telcom.ticket.model.Ticket;
import com.telcom.ticket.repository.TicketRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TicketService {
    private final TicketRepository ticketRepository;

    public TicketService(TicketRepository ticketRepository) {
        this.ticketRepository = ticketRepository;
    }

    public Ticket createTicket(Ticket ticket) {
        ticket.setCreateDateTime(java.time.LocalDateTime.now());
        ticket.setStatus(Ticket.Status.OPEN);
        return ticketRepository.save(ticket);
    }

    public Ticket updateTicket(Long id, Ticket updatedDetails) {
        Ticket ticket = ticketRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ticket not found"));

        if (updatedDetails.getStatus() != null) ticket.setStatus(updatedDetails.getStatus());
        if (updatedDetails.getResolutionDetails() != null) ticket.setResolutionDetails(updatedDetails.getResolutionDetails());
        if (updatedDetails.getResolutionDateTime() != null) ticket.setResolutionDateTime(updatedDetails.getResolutionDateTime());
        if (updatedDetails.getRequesterPhoneNumber() != null) ticket.setRequesterPhoneNumber(updatedDetails.getRequesterPhoneNumber());

        return ticketRepository.save(ticket);
    }

    public List<Ticket> fetchAllOpenTickets() {
        return ticketRepository.findByStatus(Ticket.Status.OPEN);
    }

    public Optional<Ticket> fetchTicketById(Long id) {
        return ticketRepository.findById(id);
    }
}
